# CP1404/5632 Assignment: Songs To Learn by Quang Khai Nguyen
In the project, I very appreciate that the project helps me learn and understand a lot of thing in enhancing coding skills using kivy, classes, and GUIs.
It gives me more chance to practice and more understand how the functions work together with some techniques which I used in the project.
For my assignment, I have created a simple program (popup layout) that helps the users see songs which are unlearned and some which are learned. 
The users are able to learn the song they want by clicking to the button and learn the song (the song will be turned green (learned),
so the users can easily know what songs they have learned)Moreover, the users are allowed to add a new song and fill the information of that song. 
The list of the song will be sorted in the year, so the users can easily figure out the song they want to see


The project reflection is complete and describes development and learning well, shows careful thought, highlights insights made during code development.




1. How long did the entire project (assignment 2) take you?
##
For the entire of the project, it took me a lot of time to complete due to the difficulties of the project. After finishing assignment 1 in coding python.
I continued to look at assignment 2 about kivy and classes what are quite new for me.
I had to do a researching and surfing the lecture slide and watched the video to understand more about kivy what how it works (it took me about a week and 2 days).
After that, I spent 2 another week to code my project including running, testing and fixing the error.
Building a function of clicking a button on the entry box is one of the most difficult thing that took me the most of the time.
Overall, for completing the whole project, it almost took me 1 month to understand and build it properly

2. What are you most satisfied with?
...

##
For the project, I'm most satisfied with solving successfully the entry box that helps users click to learn the song. 
Because It always occurs the errors. Therefore, I have spent a lot of time to fix it. Finally, it works properly.

3. What are you least satisfied with?
...

## 
I want to create more function about change theme color to look more nice and attractive but i do not have a time to do it

4. What worked well in your development process?
...

##
 Every functions ( add song, sort song, learn,..) work influently in my project. I'm quite happy about that. Because during building all the project, i got so many
 errors and bugs that took me a lot of time to check and find out the solution. In the end, i have fixed all of it.

5. What about your process could be improved the next time you do a project like this?
...

## 
 For next time, i would like to spend more time on researching my codes and  used it more logically. Moreover, for the next time i will definitely go and ask people to 
 get feedbacks to improve my GUI on my project 
6. Describe what resources you used and how you used them.
...

## 
i have do researching from books in library and stackoverflow to understand and find the new code and how it works. But the most useful thing,i always look at is 
KivyDemos-master file from learnjcu. It really helps me a lot in designing the layout and sort list
7. Describe the main challenges or obstacles you faced and how you overcame them.
... 

During working my project, the main challenge me is creating a function of entry box to allow user click the bar song as learned. I have spent most of the time on it and still
did not know how to do it. After reading the book code in library, i had some ideas to do and try it several time. Finally, it worked:)